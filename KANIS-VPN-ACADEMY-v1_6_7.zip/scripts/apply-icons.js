// Copie l'icône KANIS (logo officiel) dans le projet Android après « cap add android ».
// Indépendant de capacitor-assets : l'icône est toujours remplacée, même si cette étape a échoué.
const fs=require("fs"),path=require("path");
const root=path.join(__dirname,"..");
const res=path.join(root,"android","app","src","main","res");
const src=path.join(root,"resources","android-icons");
if(!fs.existsSync(res)){console.error("android/ introuvable : lance d'abord « npx cap add android ».");process.exit(1);}
for(const d of fs.readdirSync(src)){
  const to=path.join(res,d);fs.mkdirSync(to,{recursive:true});
  for(const f of fs.readdirSync(path.join(src,d)))fs.copyFileSync(path.join(src,d,f),path.join(to,f));
}
const any=path.join(res,"mipmap-anydpi-v26");fs.mkdirSync(any,{recursive:true});
const xml=`<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/kanis_icon_bg"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
`;
fs.writeFileSync(path.join(any,"ic_launcher.xml"),xml);fs.writeFileSync(path.join(any,"ic_launcher_round.xml"),xml);
const vals=path.join(res,"values");fs.mkdirSync(vals,{recursive:true});
fs.writeFileSync(path.join(vals,"kanis_icon.xml"),`<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="kanis_icon_bg">#020612</color>
</resources>
`);
// Vérification : le manifeste doit pointer vers ces icônes.
const man=fs.readFileSync(path.join(root,"android","app","src","main","AndroidManifest.xml"),"utf8");
if(!/android:icon="@mipmap\/ic_launcher"/.test(man)){console.error("Le manifeste n'utilise pas @mipmap/ic_launcher.");process.exit(1);}
console.log("Icône KANIS installée.");
