-- KANIS VPN ACADEMY — migration 002 : notifications serveur, changement de rôle côté serveur, correctifs
-- À exécuter APRÈS 001_kanis_schema.sql

-- ===== Notifications =====
create or replace function public.notify(p_user uuid, p_title text, p_body text) returns void
language sql security definer set search_path=public as $$ insert into notifications(user_id,title,body) values(p_user,p_title,p_body) $$;
revoke execute on function public.notify(uuid,text,text) from public, anon, authenticated;

create or replace function public.trg_order_notify() returns trigger language plpgsql security definer set search_path=public as $$
declare a record; begin
  if new.kind='course' then
    for a in select id from profiles where role='admin' loop perform notify(a.id,'Nouvelle commande',new.amount||' FCFA en attente de vérification'); end loop;
    if new.reseller_id is not null then perform notify(new.reseller_id,'Commande enregistrée','Vente de '||new.amount||' FCFA en attente de confirmation'); end if;
  else
    for a in select id from profiles where role='admin' loop perform notify(a.id,'Demande d''activation revendeur',new.amount||' FCFA en attente de vérification'); end loop;
  end if; return new; end $$;
create trigger orders_notify after insert on orders for each row execute function trg_order_notify();

create or replace function public.trg_code_notify() returns trigger language plpgsql security definer set search_path=public as $$
begin perform notify(new.created_by,'Nouveau code généré','Un code d''accès a été créé (se terminant par …'||new.hint||').'); return new; end $$;
create trigger codes_notify after insert on access_codes for each row execute function trg_code_notify();

create or replace function public.trg_enroll_notify() returns trigger language plpgsql security definer set search_path=public as $$
begin perform notify(new.user_id,'Formation débloquée','Ta formation est maintenant disponible.'); return new; end $$;
create trigger enroll_notify after insert on enrollments for each row execute function trg_enroll_notify();

create or replace function public.trg_promo_notify() returns trigger language plpgsql security definer set search_path=public as $$
begin if new.active and not new.applies_to_activation then perform notify(null,'Nouvelle promotion','Code '||new.code||' disponible.'); end if; return new; end $$;
create trigger promo_notify after insert on promotions for each row execute function trg_promo_notify();

-- Promotions d'activation : notification réservée aux revendeurs en attente d'activation
create or replace function public.trg_promo_act_notify() returns trigger language plpgsql security definer set search_path=public as $$
declare r record; begin
  if new.active and new.applies_to_activation then
    for r in select id from profiles where role='reseller' and reseller_status='pending' loop perform notify(r.id,'Promotion sur l''activation','Le prix d''activation est réduit. Ouvre ton espace revendeur.'); end loop; end if; return new; end $$;
create trigger promo_act_notify after insert on promotions for each row execute function trg_promo_act_notify();

-- Temps réel (les politiques RLS s'appliquent aux événements)
alter publication supabase_realtime add table public.notifications;

-- ===== confirm_payment (remplace la version 001 : contrôle d'existence + notifications) =====
create or replace function public.confirm_payment(p_payment uuid, p_reference text default null) returns void
language plpgsql security definer set search_path=public as $$
declare pay payments; o orders; share int; rc int; begin
  if not (is_admin() or auth.role()='service_role') then raise exception 'Réservé à l''administrateur'; end if;
  select * into pay from payments where id=p_payment for update;
  if not found then raise exception 'Paiement introuvable'; end if;
  if pay.status<>'pending' then raise exception 'Paiement déjà traité'; end if;
  select * into o from orders where id=pay.order_id for update;
  update payments set status='confirmed', reference=coalesce(p_reference,reference), confirmed_at=now(), confirmed_by=auth.uid() where id=pay.id;
  update orders set status='confirmed' where id=o.id;
  if o.promo_code is not null then update promotions set uses=uses+1 where upper(code)=upper(o.promo_code); end if;
  if o.kind='activation' then
    update profiles set reseller_status='active' where id=o.buyer_id;
    perform notify(o.buyer_id,'Compte revendeur activé','Ton espace revendeur est prêt.');
  elsif o.reseller_id is not null then
    select value::int into share from settings where key='reseller_share_percent';
    rc := o.amount*share/100;
    insert into commissions(reseller_id,order_id,reseller_amount,academy_amount) values(o.reseller_id,o.id,rc,o.amount-rc);
    update profiles set balance=balance+rc where id=o.reseller_id;
    perform notify(o.reseller_id,'Paiement confirmé · nouvelle commission','Commission de '||rc||' FCFA créditée. Tu peux générer le code du client.');
  else
    insert into enrollments(user_id,course_id,order_id) values(o.buyer_id,o.course_id,o.id) on conflict do nothing;  -- notifie « Formation débloquée »
    perform notify(o.buyer_id,'Paiement confirmé',o.amount||' FCFA reçus.');
  end if;
end $$;

-- ===== Rôles : uniquement côté serveur, par un administrateur =====
create or replace function public.admin_set_role(p_user uuid, p_role text) returns void language plpgsql security definer set search_path=public as $$
begin
  if not is_admin() then raise exception 'Non autorisé'; end if;
  if p_role not in ('buyer','reseller','admin') then raise exception 'Rôle invalide'; end if;
  if p_user=auth.uid() then raise exception 'Tu ne peux pas modifier ton propre rôle'; end if;
  update profiles set role=p_role, reseller_status=case when p_role='reseller' then 'active' else 'none' end where id=p_user; end $$;
