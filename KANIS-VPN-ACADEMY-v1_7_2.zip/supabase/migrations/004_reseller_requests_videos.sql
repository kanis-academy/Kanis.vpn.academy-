-- KANIS VPN ACADEMY 004 : demandes revendeur (preuve + validation manuelle + code), moyens de paiement revendeur, vidéos protégées
-- À exécuter APRÈS 001, 002, 003. Jamais testé sur un vrai PostgreSQL ici : exécute et signale toute erreur.
create extension if not exists pgcrypto;

create table if not exists public.reseller_requests(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles on delete cascade,
  full_name text not null, phone text not null, email text not null, pay_phone text not null,
  amount int not null check(amount>0), proof_path text not null,
  status text not null default 'pending' check(status in ('pending','approved','refused')),
  admin_note text, reviewed_by uuid, reviewed_at timestamptz, created_at timestamptz default now());
create unique index if not exists one_pending_request on public.reseller_requests(user_id) where status='pending';

create table if not exists public.reseller_codes(
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null unique references public.reseller_requests on delete cascade,
  user_id uuid not null references public.profiles on delete cascade,
  code_hash text unique not null,
  status text not null default 'unused' check(status in ('unused','used','revoked')),
  used_at timestamptz, created_at timestamptz default now());

create table if not exists public.reseller_payment_methods(
  id uuid primary key default gen_random_uuid(),
  reseller_id uuid not null references public.profiles on delete cascade,
  operator text not null, number text not null, holder_name text not null, instructions text,
  created_at timestamptz default now());

create table if not exists public.operation_log(
  id uuid primary key default gen_random_uuid(), actor uuid, action text not null, detail jsonb, created_at timestamptz default now());

alter table public.videos add column if not exists description text;
alter table public.videos add column if not exists thumbnail_path text;
alter table public.videos add column if not exists storage_path text;
alter table public.videos add column if not exists is_active boolean not null default true;
alter table public.courses add column if not exists code_prefix text;
update public.courses set code_prefix='DT' where slug='dark-tunnel' and code_prefix is null;
update public.courses set code_prefix='BK' where slug='bkcbebe-tunnel' and code_prefix is null;

alter table public.reseller_requests enable row level security;
alter table public.reseller_codes enable row level security;
alter table public.reseller_payment_methods enable row level security;
alter table public.operation_log enable row level security;

create policy rr_own on public.reseller_requests for select using (user_id=auth.uid() or public.is_admin());
create policy rc_admin on public.reseller_codes for select using (public.is_admin());
create policy rpm_own on public.reseller_payment_methods for all
  using (reseller_id=auth.uid() and exists(select 1 from public.profiles where id=auth.uid() and reseller_status='active'))
  with check (reseller_id=auth.uid() and exists(select 1 from public.profiles where id=auth.uid() and reseller_status='active'));
create policy rpm_admin on public.reseller_payment_methods for select using (public.is_admin());
create policy ol_admin on public.operation_log for select using (public.is_admin());

-- 1) Le futur revendeur envoie sa preuve : statut EN ATTENTE, aucune activation automatique
create or replace function public.submit_reseller_request(p_name text,p_phone text,p_email text,p_pay_phone text,p_amount int,p_proof_path text)
returns uuid language plpgsql security definer set search_path=public,extensions as $$
declare rid uuid; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if p_proof_path is null or p_proof_path not like auth.uid()::text||'/%' then raise exception 'Preuve de paiement invalide'; end if;
  if exists(select 1 from profiles where id=auth.uid() and reseller_status='active') then raise exception 'Compte déjà activé'; end if;
  insert into reseller_requests(user_id,full_name,phone,email,pay_phone,amount,proof_path)
    values(auth.uid(),trim(p_name),trim(p_phone),trim(p_email),trim(p_pay_phone),p_amount,p_proof_path) returning id into rid;
  insert into operation_log(actor,action,detail) values(auth.uid(),'reseller_request',jsonb_build_object('id',rid));
  return rid; end $$;

-- 2) L'administrateur accepte ou refuse ; le code est renvoyé UNE seule fois (seul son hash est stocké)
create or replace function public.admin_review_request(p_id uuid,p_decision text,p_note text default null)
returns text language plpgsql security definer set search_path=public,extensions as $$
declare r reseller_requests; c text; begin
  if not is_admin() then raise exception 'Non autorisé'; end if;
  select * into r from reseller_requests where id=p_id and status='pending' for update;
  if not found then raise exception 'Demande introuvable ou déjà traitée'; end if;
  if p_decision='refused' then
    update reseller_requests set status='refused',admin_note=p_note,reviewed_by=auth.uid(),reviewed_at=now() where id=p_id;
    insert into operation_log(actor,action,detail) values(auth.uid(),'request_refused',jsonb_build_object('id',p_id)); return null; end if;
  if p_decision<>'approved' then raise exception 'Décision invalide'; end if;
  c:='RV-'||upper(substr(encode(gen_random_bytes(6),'hex'),1,10));
  update reseller_requests set status='approved',admin_note=p_note,reviewed_by=auth.uid(),reviewed_at=now() where id=p_id;
  insert into reseller_codes(request_id,user_id,code_hash) values(p_id,r.user_id,encode(digest(c,'sha256'),'hex'));
  insert into operation_log(actor,action,detail) values(auth.uid(),'request_approved',jsonb_build_object('id',p_id));
  return c; end $$;

-- 3) Le revendeur saisit son code : vérification serveur, usage unique, activation
create or replace function public.redeem_reseller_code(p_code text) returns void language plpgsql security definer set search_path=public,extensions as $$
declare rc reseller_codes; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  select * into rc from reseller_codes where code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex') and status='unused' and user_id=auth.uid() for update;
  if not found then raise exception 'Code invalide ou déjà utilisé'; end if;
  update reseller_codes set status='used',used_at=now() where id=rc.id;
  update profiles set role='reseller',reseller_status='active' where id=auth.uid() and role<>'admin';
  insert into operation_log(actor,action,detail) values(auth.uid(),'reseller_activated',jsonb_build_object('code_id',rc.id)); end $$;

-- 4) Clients : voir les moyens de paiement d'un revendeur actif (jamais ceux de l'admin)
create or replace function public.get_reseller_methods(p_reseller uuid) returns table(operator text,number text,holder_name text,instructions text)
language sql stable security definer set search_path=public,extensions as $$
  select m.operator,m.number,m.holder_name,m.instructions from reseller_payment_methods m
  join profiles p on p.id=m.reseller_id where m.reseller_id=p_reseller and p.reseller_status='active' $$;

-- 5) Vidéos : la liste (titre, description, miniature) est visible, jamais le fichier sans droit
create or replace function public.list_course_videos(p_slug text) returns table(id uuid,title text,description text,thumbnail_path text,pos int,unlocked boolean)
language sql stable security definer set search_path=public,extensions as $$
  select v.id,v.title,v.description,v.thumbnail_path,v.position,
   (is_admin() or exists(select 1 from enrollments e where e.course_id=c.id and e.user_id=auth.uid()))
  from videos v join courses c on c.id=v.course_id where c.slug=p_slug and v.is_active order by v.position $$;

-- Buckets privés
insert into storage.buckets(id,name,public) values('proofs','proofs',false),('videos','videos',false),('thumbs','thumbs',true) on conflict do nothing;
create policy proofs_ins on storage.objects for insert to authenticated with check(bucket_id='proofs' and (storage.foldername(name))[1]=auth.uid()::text);
create policy proofs_sel on storage.objects for select to authenticated using(bucket_id='proofs' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_admin()));
create policy videos_admin on storage.objects for all to authenticated using(bucket_id in ('videos','thumbs') and public.is_admin()) with check(bucket_id in ('videos','thumbs') and public.is_admin());
create policy videos_sel on storage.objects for select to authenticated using(bucket_id='videos' and exists(
  select 1 from public.videos v join public.enrollments e on e.course_id=v.course_id where v.storage_path=name and v.is_active and e.user_id=auth.uid()));

revoke execute on function public.submit_reseller_request(text,text,text,text,int,text),public.admin_review_request(uuid,text,text),
  public.redeem_reseller_code(text),public.get_reseller_methods(uuid),public.list_course_videos(text) from anon;

-- ===== Promotion des prix (automatique : prix promo pendant la période, prix normal ensuite) =====
create table if not exists public.price_promos(id uuid primary key default gen_random_uuid(), course_id uuid not null references public.courses on delete cascade,
  promo_price int not null check(promo_price>=0), starts_at timestamptz, ends_at timestamptz not null, active boolean not null default true, created_at timestamptz default now());
alter table public.price_promos enable row level security;
create policy pp_admin on public.price_promos for all using(public.is_admin()) with check(public.is_admin());
create or replace function public.price_for(p_course uuid, p_promo text, p_activation boolean default false) returns int
language plpgsql stable security definer set search_path=public,extensions as $$
declare base int; pr promotions; res int;
begin
  if p_activation then select value::int into base from settings where key='reseller_activation_price';
  else select coalesce((select pp.promo_price from price_promos pp where pp.course_id=c.id and pp.active and (pp.starts_at is null or pp.starts_at<=now()) and pp.ends_at>=now() order by pp.promo_price limit 1),c.price) into base from courses c where c.id=p_course and c.active; end if;
  if base is null then raise exception 'Formation introuvable'; end if;
  if p_promo is null or p_promo='' then return base; end if;
  select * into pr from promotions where upper(code)=upper(p_promo) and active
     and (starts_at is null or starts_at<=now()) and (ends_at is null or ends_at>=now())
     and (max_uses is null or uses<max_uses)
     and ((p_activation and applies_to_activation) or (not p_activation and (course_ids='{}' or p_course=any(course_ids))));
  if not found then return base; end if;
  res := case when pr.kind='percent' then base - base*least(pr.value,100)/100 else greatest(base-pr.value,0) end;
  return res; end $$;

-- ===== Codes de formation : préfixe DT (Dark Tunnel) / BK (BKCBEBE Tunnel) ; chaque code ne débloque que sa formation =====
create or replace function public.generate_code(p_order uuid) returns text language plpgsql security definer set search_path=public,extensions as $$
declare o orders; plain text; begin
  select * into o from orders where id=p_order;
  if not found or o.kind<>'course' or o.status<>'confirmed' then raise exception 'Commande non confirmée'; end if;
  if not (is_admin() or o.reseller_id=auth.uid()) then raise exception 'Non autorisé'; end if;
  if exists(select 1 from access_codes where order_id=p_order) then raise exception 'Code déjà généré pour cette commande'; end if;
  if o.reseller_id is not null and not exists(select 1 from profiles where id=o.reseller_id and reseller_status='active') then raise exception 'Revendeur suspendu'; end if;
  plain := (select coalesce(code_prefix,upper(substr(slug,1,2))) from courses where id=o.course_id)||'-'||upper(encode(gen_random_bytes(5),'hex'));
  insert into access_codes(code_hash,hint,course_id,order_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),o.course_id,p_order,auth.uid());
  return plain; end $$;

-- ===== Sources vidéo (accès vérifié côté serveur ; le fichier privé est servi par URL signée) =====
create or replace function public.get_video_sources(p_slug text) returns table(id uuid,title text,description text,url text,storage_path text,chapter text,pos int)
language sql stable security definer set search_path=public,extensions as $$
  select v.id,v.title,v.description,case when v.storage_path is null then v.url else null end,v.storage_path,ch.title,v.position
  from videos v join courses c on c.id=v.course_id left join chapters ch on ch.id=v.chapter_id
  where c.slug=p_slug and v.is_active and (is_admin() or exists(select 1 from enrollments e where e.course_id=c.id and e.user_id=auth.uid())) order by v.position $$;
revoke execute on function public.get_video_sources(text) from anon;

-- Les vidéos désactivées ne sont plus servies
create or replace function public.get_course_videos(p_slug text) returns table(title text,url text,chapter text,pos int)
language sql stable security definer set search_path=public,extensions as $$
  select v.title,v.url,ch.title,v.position from videos v join courses c on c.id=v.course_id left join chapters ch on ch.id=v.chapter_id
  where c.slug=p_slug and v.is_active and (is_admin() or exists(select 1 from enrollments e where e.course_id=c.id and e.user_id=auth.uid())) order by v.position $$;
