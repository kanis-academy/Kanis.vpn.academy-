-- KANIS VPN ACADEMY 006 : réinitialisation SANS que l'administrateur connaisse le mot de passe
-- L'admin « initialise » l'accès (24 h) ; le client choisit lui-même son nouveau mot de passe (e-mail + numéro de téléphone du compte).
-- À exécuter APRÈS 005.
alter table public.profiles add column if not exists reset_until timestamptz;
alter table public.profiles add column if not exists reset_attempts int not null default 0;
drop function if exists public.admin_reset_password(text);

create or replace function public.admin_init_reset(p_email text) returns void
language plpgsql security definer set search_path=public,extensions,auth as $$
declare uid uuid; begin
  if not public.is_admin() then raise exception 'Non autorisé'; end if;
  select id into uid from auth.users where lower(email)=lower(trim(p_email));
  if uid is null then raise exception 'Aucun compte avec cet e-mail'; end if;
  -- l'ancien mot de passe est invalidé ; le nouveau mot de passe n'est connu de personne tant que le client ne l'a pas choisi
  update auth.users set encrypted_password=crypt(encode(gen_random_bytes(24),'hex'),gen_salt('bf')),
    email_confirmed_at=coalesce(email_confirmed_at,now()), updated_at=now() where id=uid;
  update public.profiles set reset_until=now()+interval '24 hours', reset_attempts=0 where id=uid;
  insert into public.operation_log(actor,action,detail) values(auth.uid(),'reset_initialized',jsonb_build_object('user',uid));
end $$;

-- Le client choisit son mot de passe : e-mail + téléphone du compte, 5 essais maximum, valable 24 h, une seule fois
create or replace function public.claim_reset(p_email text,p_phone text,p_new text) returns text
language plpgsql security definer set search_path=public,extensions,auth as $$
declare uid uuid; pr public.profiles; a text; b text; begin
  if length(coalesce(p_new,''))<8 then return 'ko'; end if;
  select id into uid from auth.users where lower(email)=lower(trim(p_email));
  if uid is null then return 'ko'; end if;
  select * into pr from public.profiles where id=uid;
  if pr.id is null or pr.reset_until is null or pr.reset_until<now() or pr.reset_attempts>=5 then return 'ko'; end if;
  a:=right(regexp_replace(coalesce(pr.phone,''),'\D','','g'),8); b:=right(regexp_replace(coalesce(p_phone,''),'\D','','g'),8);
  if a='' or a<>b then update public.profiles set reset_attempts=reset_attempts+1 where id=uid; return 'ko'; end if;
  update auth.users set encrypted_password=crypt(p_new,gen_salt('bf')), updated_at=now() where id=uid;
  update public.profiles set reset_until=null, reset_attempts=0 where id=uid;
  insert into public.operation_log(actor,action,detail) values(null,'reset_claimed',jsonb_build_object('user',uid));
  return 'ok'; end $$;

revoke execute on function public.admin_init_reset(text) from anon, public;
grant execute on function public.admin_init_reset(text) to authenticated;
grant execute on function public.claim_reset(text,text,text) to anon, authenticated;
