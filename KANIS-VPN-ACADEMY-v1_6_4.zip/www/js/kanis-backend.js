/* KANIS VPN ACADEMY — connexion Supabase, comptes, tableaux de bord (acheteur / revendeur / admin) */
(function(){
"use strict";
var C=window.KANIS_SUPABASE||{}, KV=window.KV={on:false,access:[],profile:null,db:null};
var FMT=function(n){return Number(n||0).toLocaleString("fr-FR")+" FCFA";};
function h(t,a,k){var e=document.createElement(t);for(var x in a||{}){if(x==="class")e.className=a[x];else if(x.slice(0,2)==="on")e.addEventListener(x.slice(2),a[x]);else e.setAttribute(x,a[x]);}
  [].concat(k==null?[]:k).forEach(function(c){if(c!=null)e.appendChild(typeof c==="object"?c:document.createTextNode(String(c)));});return e;}
function toast(m){if(window.KANIS&&KANIS.toast)KANIS.toast(m);else alert(m);}
var css=".kv{position:fixed;inset:0;z-index:90;background:var(--bg,#f5f3ee);color:var(--ink,#24262b);overflow:auto;padding:calc(env(safe-area-inset-top,0px) + 12px) 14px calc(env(safe-area-inset-bottom,0px) + 24px);font:15px/1.45 system-ui,sans-serif}"+
".kv[hidden]{display:none}.kv .in{max-width:620px;margin:0 auto}.kv img.lg{display:block;width:96px;height:96px;margin:6px auto;border-radius:22px}"+
".kv h2{margin:10px 0 6px;font-size:20px}.kv h3{margin:16px 0 6px;font-size:16px}.kv .c{background:var(--surface,#fff);border:1px solid var(--line,#e2ded4);border-radius:14px;padding:12px;margin:8px 0}"+
".kv label{display:block;margin:8px 0;font-size:13px;color:var(--muted,#62646b)}.kv input,.kv select{display:block;width:100%;box-sizing:border-box;margin-top:4px;padding:11px;border:1px solid var(--line,#e2ded4);border-radius:10px;background:var(--bg,#fff);color:inherit;font-size:15px}"+
".kv button{border:0;border-radius:10px;padding:11px 14px;margin:4px 4px 4px 0;background:var(--accent,#d4a017);color:var(--accent-ink,#1b1400);font-weight:700;font-size:14px}.kv button.alt{background:transparent;border:1px solid var(--line,#ccc);color:inherit}"+
".kv .tabs{display:flex;gap:6px;overflow-x:auto;padding:6px 0}.kv .tabs button{white-space:nowrap;margin:0}.kv .row{display:flex;justify-content:space-between;gap:8px;padding:8px 0;border-bottom:1px solid var(--line,#e2ded4);font-size:13px;flex-wrap:wrap}"+
".kv .k{display:grid;grid-template-columns:1fr 1fr;gap:8px}.kv .k b{display:block;font-size:18px}.kv .err{color:#d22f3c}.kv .ok{color:#1e9e5a}.kv s{color:var(--muted,#888)}.kv .tag{padding:2px 8px;border-radius:99px;background:var(--line,#e2ded4);font-size:12px}";
document.head.appendChild(h("style",{},css));
var css2=".kv h2{text-align:center}.kv .ctr{text-align:center}.kv button.big{display:block;width:100%;padding:15px;font-size:16px;margin:10px 0;border-radius:14px}"+
".kv .price{text-align:center;border:2px solid var(--accent,#d4a017);background:var(--surface,#fff);border-radius:16px;padding:14px;margin:10px 0}.kv .price[hidden]{display:none}"+
".kv .price small{display:block;font-size:11px;letter-spacing:.08em;color:var(--muted,#62646b);font-weight:700;margin:3px 0}.kv .price b{display:block;font-size:30px;margin:4px 0}"+
".kv a{color:var(--accent,#b8860b);font-weight:600}#toast{z-index:300}";
document.head.appendChild(h("style",{},css2));
var root=h("div",{class:"kv",hidden:"",role:"dialog","aria-label":"Mon compte"});document.body.appendChild(root);
function open(v){root.hidden=!v;}
function head(t){return h("div",{},[h("img",{class:"lg",src:"img/logo.png",alt:"KANIS VPN ACADEMY"}),h("h2",{},t)]);}
function form(fields,label,fn){var f=h("form",{}),inp={},err=h("p",{class:"err"});
  fields.forEach(function(d){var i=d.opts?h("select",{},d.opts.map(function(o){return h("option",{value:o[0]},o[1]);})):h("input",{type:d.t||"text",autocomplete:d.ac||"off",value:d.v||""});if(d.v&&d.opts)i.value=d.v;inp[d.k]=i;f.appendChild(h("label",{},[d.l,i]));});
  f.appendChild(err);var b=h("button",{type:"submit"},label);f.appendChild(b);
  f.addEventListener("submit",async function(e){e.preventDefault();err.textContent="";b.disabled=true;var v={};for(var k in inp)v[k]=inp[k].type==="password"?inp[k].value:inp[k].value.trim();
    try{await fn(v);}catch(x){err.textContent=x.message||String(x);}b.disabled=false;});return f;}
async function rpc(n,a){var r=await KV.db.rpc(n,a||{});if(r.error)throw r.error;return r.data;}
async function q(p){var r=await p;if(r.error)throw r.error;return r.data;}
function rows(list,fn){return h("div",{},list.length?list.map(fn):[h("p",{class:"tag"},"Aucune donnée")]);}
function row(a,b){return h("div",{class:"row"},[h("span",{},a),h("span",{},b)]);}

/* ---------- Notifications (serveur + locales Android) ---------- */
function pushLocal(t,b){try{var P=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.LocalNotifications;if(P)P.schedule({notifications:[{id:Math.floor(Math.random()*2e9),title:t,body:b||"",schedule:{at:new Date(Date.now()+400)}}]});}catch(e){}}
async function notifCard(){var ns=await q(KV.db.from("notifications").select("*").order("created_at",{ascending:false}).limit(20));
  return h("div",{class:"c"},[h("h3",{},"Notifications"),rows(ns,function(n){return h("div",{class:"row"},[h("span",{},[h("b",{},n.title),h("br"),n.body||""]),h("span",{class:"tag"},new Date(n.created_at).toLocaleDateString("fr-FR"))]);})]);}
function listen(){if(KV.ch){KV.db.removeChannel(KV.ch);KV.ch=null;}if(!KV.session)return;var me=KV.session.user.id;
  KV.ch=KV.db.channel("n-"+me).on("postgres_changes",{event:"INSERT",schema:"public",table:"notifications"},function(p){var n=p.new;if(n.user_id&&n.user_id!==me)return;pushLocal(n.title,n.body);toast(n.title);if(!root.hidden)dash();}).subscribe();
  catchUp();}
async function catchUp(){try{var k="kv_seen_"+KV.session.user.id,last=localStorage.getItem(k),now=new Date().toISOString();
  if(last){var ns=await q(KV.db.from("notifications").select("*").gt("created_at",last).order("created_at").limit(3));ns.forEach(function(n){pushLocal(n.title,n.body);});}localStorage.setItem(k,now);}catch(e){}}

/* ---------- Accès aux formations (décidé par le serveur) ---------- */
KV.has=function(k){return KV.access.indexOf(k)>-1;};
KV.refresh=async function(){try{KV.access=KV.db&&KV.session?await rpc("my_access"):[];}catch(e){KV.access=[];}};
KV.redeem=async function(code){if(!KV.session){toast("Connecte-toi pour utiliser un code");KV.openAccount();return null;}
  try{var s=await rpc("redeem_code",{p_code:code});await KV.refresh();return s;}catch(e){toast(e.message);return null;}};
function player(v){var m=String(v.url).match(/(?:youtu\.be\/|[?&]v=|\/embed\/)([A-Za-z0-9_-]{11})/),w=h("div",{class:"c"},[h("b",{},(v.chapter?v.chapter+" · ":"")+v.title)]);
  if(v.signed||/\.(mp4|webm)(\?.*)?$/i.test(v.url))w.appendChild(h("video",{controls:"",playsinline:"",preload:"metadata",controlslist:"nodownload noplaybackrate",disablepictureinpicture:"",oncontextmenu:function(e){e.preventDefault();},src:v.url,style:"width:100%;border-radius:10px;margin-top:6px"}));
  else if(m)w.appendChild(h("iframe",{src:"https://www.youtube-nocookie.com/embed/"+m[1]+"?rel=0&playsinline=1",allowfullscreen:"",style:"width:100%;aspect-ratio:16/9;border:0;border-radius:10px;margin-top:6px"}));
  else w.appendChild(h("a",{href:v.url,target:"_blank",rel:"noopener"},"Ouvrir la vidéo"));return w;}
KV.renderVideo=async function(key,box){box.textContent="";
  try{var vs=await rpc("get_video_sources",{p_slug:key});if(!vs.length)box.appendChild(h("p",{},"Vidéo bientôt disponible."));
    for(var i=0;i<vs.length;i++){var v=vs[i];if(v.storage_path){var su=await KV.db.storage.from("videos").createSignedUrl(v.storage_path,7200);if(su.error){box.appendChild(h("p",{class:"err"},"Vidéo indisponible."));continue;}v.url=su.data.signedUrl;v.signed=true;}
      var pl=player(v);if(v.description)pl.appendChild(h("p",{},v.description));box.appendChild(pl);}}
  catch(e){box.appendChild(h("p",{class:"err"},"Impossible de charger la vidéo : "+e.message));}};

/* ---------- Authentification (inscription directe, sans confirmation e-mail) ---------- */
var NATIVE=!!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform());
var CALLBACK="kanisvpn://auth-callback";
var CONFIRM_HELP="Dans Supabase : Authentication → Sign In / Providers → Email → désactive « Confirm email » → Save.";
var STATUS={pending:"En attente de vérification",confirmed:"Confirmé",refused:"Refusé",refunded:"Remboursé"};
var PROV={orange_money:"Orange Money",wave:"Wave",manual:"Manuel"};
function stopPoll(){if(KV.poll){clearInterval(KV.poll);KV.poll=null;}}
function mapErr(e){var m=String((e&&e.message)||e||""),c=String((e&&(e.code||e.error_code))||""),all=m+" "+c;
  if(/already registered|already been registered|user_already_exists/i.test(all))return "Un compte existe déjà avec cet e-mail. Connecte-toi.";
  if(/invalid login credentials|invalid_credentials/i.test(all))return "E-mail ou mot de passe incorrect.";
  if(/email not confirmed|email_not_confirmed/i.test(all))return "Supabase exige encore la confirmation par e-mail pour ce compte. "+CONFIRM_HELP;
  if(/rate limit|too many|over_.*_rate_limit|\b429\b/i.test(all))return "Trop de tentatives. Patiente quelques minutes puis réessaie.";
  if(/signup.*disabled|signups not allowed|signup_disabled/i.test(all))return "Les inscriptions sont désactivées dans Supabase (Authentication → Sign In / Providers → « Allow new users to sign up »).";
  if(/password/i.test(m)&&/(should|least|weak|short|characters)/i.test(m))return "Mot de passe refusé : 8 caractères minimum et pas trop simple.";
  if(/database error saving new user/i.test(m))return "Le profil n’a pas pu être créé : exécute les migrations SQL 001, 002 puis 003 dans Supabase.";
  if(/failed to fetch|networkerror|load failed|network request/i.test(m))return "Pas de connexion Internet, ou serveur Supabase injoignable.";
  if(/invalid api key|apikey/i.test(all))return "Clé Supabase invalide : l’URL et la clé publique de config.js doivent venir du MÊME projet.";
  return m||"Erreur inconnue";}
function shell(title){stopPoll();root.textContent="";root.className="kv";var b=h("div",{class:"in"});root.appendChild(b);b.appendChild(head(title));open(true);return b;}
function logoutBtn(){return h("button",{class:"alt",onclick:function(){logout();}},"Se déconnecter");}
async function logout(){stopPoll();KV.leaving=true;try{if(KV.ch){KV.db.removeChannel(KV.ch);KV.ch=null;}await KV.db.auth.signOut();}catch(e){}
  KV.session=null;KV.profile=null;KV.access=[];KV.locked=true;KV.leaving=false;welcome();}
function errorView(msg){var b=shell("Connexion impossible");b.appendChild(h("div",{class:"c"},[h("p",{class:"err"},msg),h("button",{onclick:function(){route();}},"Réessayer"),logoutBtn()]));}

function welcome(){var b=shell("Bienvenue");
  b.appendChild(h("p",{class:"ctr"},"Apprends, protège ta connexion et réussis avec KANIS VPN ACADEMY."));
  b.appendChild(h("button",{class:"big",onclick:function(){signupView();}},"CRÉER UN COMPTE"));
  b.appendChild(h("button",{class:"big alt",onclick:function(){loginView();}},"SE CONNECTER"));
  b.appendChild(h("p",{class:"ctr"},h("a",{href:"#",onclick:function(e){e.preventDefault();forgotView();}},"Mot de passe oublié ?")));}

function loginView(){var b=shell("Connexion"),c=h("div",{class:"c"});b.appendChild(c);
  c.appendChild(form([{k:"email",l:"Adresse e-mail",t:"email",ac:"email"},{k:"pw",l:"Mot de passe",t:"password",ac:"current-password"}],"SE CONNECTER",async function(v){
    if(!v.email||!v.pw)throw new Error("Saisis ton e-mail et ton mot de passe.");
    var r=await KV.db.auth.signInWithPassword({email:v.email,password:v.pw});if(r.error)throw new Error(mapErr(r.error));
    KV.session=r.data.session;await route();}));
  b.appendChild(h("p",{class:"ctr"},[h("a",{href:"#",onclick:function(e){e.preventDefault();forgotView();}},"Mot de passe oublié ?")]));
  b.appendChild(h("div",{},[h("button",{class:"alt",onclick:function(){signupView();}},"Créer un compte"),h("button",{class:"alt",onclick:welcome},"Retour")]));}

function signupView(type){var b=shell("Créer un compte");
  var banner=h("div",{class:"price",hidden:""});b.appendChild(banner);
  var c=h("div",{class:"c"});b.appendChild(c);
  var f=form([{k:"type",l:"Type de compte",opts:[["buyer","Acheteur"],["reseller","Revendeur"]],v:type||"buyer"},
    {k:"name",l:"Nom complet",ac:"name"},{k:"email",l:"Adresse e-mail",t:"email",ac:"email"},{k:"phone",l:"Numéro de téléphone",t:"tel",ac:"tel"},
    {k:"pw",l:"Mot de passe (8 caractères min.)",t:"password",ac:"new-password"},{k:"pw2",l:"Confirmer le mot de passe",t:"password",ac:"new-password"}],"CRÉER MON COMPTE",async function(v){
    if(v.name.length<3)throw new Error("Saisis ton nom complet.");
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email))throw new Error("Adresse e-mail invalide.");
    if(v.phone.replace(/\D/g,"").length<8)throw new Error("Numéro de téléphone invalide.");
    if(v.pw.length<8)throw new Error("Le mot de passe doit avoir au moins 8 caractères.");
    if(v.pw!==v.pw2)throw new Error("Les deux mots de passe ne sont pas identiques.");
    if(KV.lastSignup&&Date.now()-KV.lastSignup<4000)throw new Error("Patiente quelques secondes avant de réessayer.");KV.lastSignup=Date.now();
    var r=await KV.db.auth.signUp({email:v.email,password:v.pw,options:{emailRedirectTo:NATIVE?CALLBACK:(C.redirectTo||location.origin+"/"),data:{full_name:v.name,phone:v.phone,want_reseller:v.type==="reseller"?"true":"false"}}});
    if(r.error)throw new Error(mapErr(r.error));
    if(r.data.user&&r.data.user.identities&&r.data.user.identities.length===0)throw new Error("Un compte existe déjà avec cet e-mail. Connecte-toi.");
    if(!r.data.session){noSessionView();return;}                       // jamais « connecté » sans vraie session
    KV.session=r.data.session;await route();});
  c.appendChild(f);
  var sel=f.querySelector("select");
  function paint(base,fin){banner.textContent="";banner.appendChild(h("small",{},"ACTIVATION DU COMPTE REVENDEUR"));
    banner.appendChild(h("b",{},[fin<base?h("s",{},FMT(base)):null,fin<base?" ":null,FMT(fin)]));
    if(fin<base)banner.appendChild(h("small",{},"Promotion en cours appliquée automatiquement"));
    banner.appendChild(h("small",{},"À payer après la création du compte. Le compte reste INACTIF jusqu’à la confirmation du paiement."));}
  async function upd(){if(sel.value!=="reseller"){banner.hidden=true;return;}banner.hidden=false;paint(3000,3000);
    try{var p=await rpc("activation_quote");if(sel.value==="reseller")paint(p.base,p.final);}catch(e){}}
  sel.addEventListener("change",upd);upd();
  b.appendChild(h("div",{},[h("button",{class:"alt",onclick:function(){loginView();}},"J’ai déjà un compte"),h("button",{class:"alt",onclick:welcome},"Retour")]));}

function noSessionView(){var b=shell("Compte créé, session non ouverte");
  b.appendChild(h("div",{class:"c"},[h("p",{class:"err"},"Ton compte existe, mais Supabase n’a pas ouvert de session : la confirmation par e-mail est encore activée sur le serveur."),
    h("p",{},CONFIRM_HELP),h("p",{class:"tag"},"Une fois désactivée, les nouveaux comptes seront connectés directement. Pour ce compte, demande à l’administrateur de le confirmer (Authentication → Users)."),
    h("button",{onclick:function(){loginView();}},"Se connecter"),h("button",{class:"alt",onclick:welcome},"Retour")]));}

function forgotView(){var b=shell("Mot de passe oublié"),c=h("div",{class:"c"});b.appendChild(c);
  c.appendChild(form([{k:"email",l:"Adresse e-mail du compte",t:"email",ac:"email"}],"ENVOYER LE LIEN",async function(v){
    if(!v.email)throw new Error("Saisis ton adresse e-mail.");
    var r=await KV.db.auth.resetPasswordForEmail(v.email,{redirectTo:NATIVE?CALLBACK:(C.redirectTo||location.origin+"/")});if(r.error)throw new Error(mapErr(r.error));
    c.appendChild(h("p",{class:"ok"},"Si ce compte existe, un e-mail de réinitialisation vient d’être envoyé. Ouvre le lien depuis ce téléphone."));}));
  b.appendChild(h("button",{class:"alt",onclick:function(){loginView();}},"Retour à la connexion"));}

function recoveryView(){var b=shell("Nouveau mot de passe"),c=h("div",{class:"c"});b.appendChild(c);
  c.appendChild(form([{k:"pw",l:"Nouveau mot de passe (8 caractères min.)",t:"password",ac:"new-password"},{k:"pw2",l:"Confirmer le mot de passe",t:"password",ac:"new-password"}],"ENREGISTRER",async function(v){
    if(v.pw.length<8)throw new Error("8 caractères minimum.");if(v.pw!==v.pw2)throw new Error("Les deux mots de passe ne sont pas identiques.");
    var r=await KV.db.auth.updateUser({password:v.pw});if(r.error)throw new Error(mapErr(r.error));toast("Mot de passe modifié ✓");await route();}));}

function linkError(msg){var b=shell("Lien invalide ou expiré");
  b.appendChild(h("div",{class:"c"},[h("p",{class:"err"},msg||"Ce lien est expiré ou a déjà été utilisé."),h("button",{onclick:forgotView},"Demander un nouveau lien"),h("button",{class:"alt",onclick:function(){route();}},"Retour")]));}

/* Lien profond Android : kanisvpn://auth-callback#access_token=…&type=recovery */
async function handleCallback(url){var u=String(url||"");if(u.indexOf("auth-callback")<0)return;
  try{var q={},parts=u.split("#"),qs=(parts[0].split("?")[1]||""),hs=parts.slice(1).join("#");
    (qs+"&"+hs).split("&").forEach(function(p){if(!p)return;var i=p.indexOf("=");if(i<1)return;q[decodeURIComponent(p.slice(0,i))]=decodeURIComponent(p.slice(i+1).replace(/\+/g," "));});
    if(q.error||q.error_code||q.error_description){linkError(/expired|otp_expired/i.test((q.error_code||"")+(q.error_description||""))?"Ce lien est expiré. Demande-en un nouveau.":(q.error_description||"Lien invalide."));return;}
    if(q.access_token&&q.refresh_token){var r=await KV.db.auth.setSession({access_token:q.access_token,refresh_token:q.refresh_token});if(r.error)throw r.error;KV.session=r.data.session;
      if(q.type==="recovery"){recoveryView();return;}await route();return;}
    linkError("Lien incomplet : redemande un nouveau lien.");
  }catch(e){linkError("Lien invalide ou expiré. "+mapErr(e));}}
function wireDeepLinks(){try{var A=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.App;if(!A)return;
  A.addListener("appUrlOpen",function(e){handleCallback(e&&e.url);});
  if(A.getLaunchUrl)A.getLaunchUrl().then(function(r){if(r&&r.url)handleCallback(r.url);}).catch(function(){});}catch(e){}}

/* ---------- Profil, redirection selon rôle et statut ---------- */
async function loadProfile(){var id=KV.session.user.id,r=await KV.db.from("profiles").select("*").eq("id",id).maybeSingle();if(r.error)throw r.error;
  if(!r.data){var e=await KV.db.rpc("ensure_profile");if(e.error)throw e.error;r=await KV.db.from("profiles").select("*").eq("id",id).maybeSingle();if(r.error)throw r.error;}
  if(!r.data)throw new Error("Profil introuvable : exécute la migration SQL 003.");return r.data;}
async function route(){stopPoll();
  if(!KV.session){KV.profile=null;KV.access=[];KV.locked=true;welcome();return;}
  var p;try{p=await loadProfile();}catch(e){var m=String((e&&e.message)||"")+(e&&e.code||"");
    if(/jwt|token|PGRST30|401/i.test(m)){try{await KV.db.auth.signOut({scope:"local"});}catch(x){}KV.session=null;KV.locked=true;welcome();return;}
    errorView(mapErr(e));return;}
  KV.profile=p;listen();await KV.refresh();
  if(p.role==="reseller"&&p.reseller_status!=="active"){KV.locked=true;await activationView();return;}   // revendeur inactif : page d’activation obligatoire
  KV.locked=false;await dash();}

/* ---------- Page d'activation du compte revendeur ---------- */
var USSD="*144*2*1*44947055*3000#",WAST="display:block;text-align:center;margin-top:10px;padding:12px;border-radius:12px;background:#25D366;color:#fff;font-weight:700;text-decoration:none";
function waUrl(n,t){return "https://wa.me/"+String(n||"").replace(/\D/g,"")+"?text="+encodeURIComponent(t);}
function copyTxt(t){try{navigator.clipboard.writeText(t).then(function(){toast("Copié ✓");},function(){toast(t);});}catch(e){toast(t);}}
async function upl(bucket,file,uid){var ext=(file.name.split(".").pop()||"bin").replace(/[^a-z0-9]/gi,"").slice(0,5)||"bin",path=uid+"/"+Date.now()+"-"+Math.random().toString(36).slice(2,7)+"."+ext;var r=await KV.db.storage.from(bucket).upload(path,file,{contentType:file.type});if(r.error)throw r.error;return path;}
function thumbUrl(p){return p?KV.db.storage.from("thumbs").getPublicUrl(p).data.publicUrl:"";}
async function priced(cs){await Promise.all(cs.map(async function(c){try{c.eff=await rpc("price_for",{p_course:c.id,p_promo:null});}catch(e){c.eff=c.price;}}));return cs;}
function priceEl(c){var e=c.eff==null?c.price:c.eff;return e<c.price?h("p",{},[h("s",{},FMT(c.price)),"  ",h("b",{},FMT(e)+" (PROMO)")]):h("p",{},FMT(c.price));}
function vidList(c,vl){if(!vl.length)return [h("p",{class:"tag"},"Aucune vidéo pour l’instant.")];return vl.map(function(v){var tu=thumbUrl(v.thumbnail_path),k=h("div",{class:"c"},[tu?h("img",{src:tu,alt:"",style:"width:100%;border-radius:10px"}):null,h("b",{},v.title),h("p",{},v.description||"")]);
  if(v.unlocked)k.appendChild(h("button",{onclick:function(){open(false);window.KANIS.openCourse(c.slug);}},"▶ Regarder"));
  else{k.appendChild(h("p",{class:"tag"},"🔒 VIDÉO VERROUILLÉE"));k.appendChild(h("button",{onclick:function(){btab="Codes";dash();}},"DÉVERROUILLER AVEC UN CODE"));}return k;});}
function codeOk(){var b=shell("Félicitations");b.appendChild(h("div",{class:"c"},[h("h3",{},"FÉLICITATIONS ! 🎉"),h("p",{},"Votre code d’accès est valide !"),h("p",{},"Votre formation vient d’être activée avec succès. Vous pouvez maintenant regarder toutes les vidéos de cette formation."),h("p",{},"Bonne formation sur KANIS VPN ACADEMY !"),h("button",{onclick:function(){btab="Vidéos";dash();}},"REGARDER MES VIDÉOS")]));}
function vidForm(cs2,chs){var f=h("form",{}),err=h("p",{class:"err"}),F={};
  function add(k,l,i){F[k]=i;f.appendChild(h("label",{},[l,i]));}
  add("course","Formation",h("select",{},cs2.map(function(c){return h("option",{value:c.id},c.title);})));
  add("chapter","Chapitre",h("select",{},[h("option",{value:""},"—")].concat(chs.map(function(c){return h("option",{value:c.id},c.title);}))));
  add("title","Titre",h("input",{type:"text",required:"required"}));add("desc","Description détaillée",h("textarea",{rows:"3"}));add("pos","Ordre d’affichage",h("input",{type:"number",value:"0"}));
  add("thumb","Miniature (image)",h("input",{type:"file",accept:"image/*"}));add("file","Fichier vidéo (MP4/WebM, stockage privé)",h("input",{type:"file",accept:"video/mp4,video/webm"}));add("url","… ou lien YouTube non répertorié",h("input",{type:"text"}));
  var btn=h("button",{type:"submit"},"Ajouter");f.appendChild(err);f.appendChild(btn);
  f.addEventListener("submit",async function(e){e.preventDefault();err.textContent="";var vf=F.file.files[0],url=F.url.value.trim();if(!vf&&!url){err.textContent="Ajoute un fichier vidéo ou un lien.";return;}btn.disabled=true;
    try{var uid=KV.profile.id,sp=vf?await upl("videos",vf,uid):null,tp=F.thumb.files[0]?await upl("thumbs",F.thumb.files[0],uid):null;
      await q(KV.db.from("videos").insert({course_id:F.course.value,chapter_id:F.chapter.value||null,title:F.title.value.trim(),description:F.desc.value.trim(),url:url||("storage:"+sp),storage_path:sp,thumbnail_path:tp,position:+F.pos.value||0}));dash();}
    catch(x){err.textContent=mapErr(x);}btn.disabled=false;});return f;}
function waBlock(){return h("div",{class:"c"},[h("p",{},"Vous souhaitez devenir revendeur ? Vous avez une question sur le paiement ou votre activation ? Contactez directement l’administrateur sur WhatsApp."),
  h("a",{href:waUrl(C.whatsapp,"Bonjour, je souhaite devenir revendeur KANIS VPN ACADEMY. Je voudrais obtenir les informations pour effectuer mon paiement de 3 000 FCFA et recevoir mon code d’activation."),target:"_blank",rel:"noopener",style:WAST},"CONTACTER SUR WHATSAPP")]);}
function proofForm(p){var f=h("form",{}),err=h("p",{class:"err"}),F={};
  [["name","Nom complet","text",p.full_name||""],["phone","Téléphone","tel",p.phone||""],["email","Adresse e-mail","email",p.email||""],["pay","Numéro utilisé pour le paiement","tel",""],["amount","Montant (FCFA)","number","3000"]].forEach(function(d){var i=h("input",{type:d[2],value:d[3],required:"required"});F[d[0]]=i;f.appendChild(h("label",{},[d[1],i]));});
  var file=h("input",{type:"file",accept:"image/*",required:"required"});f.appendChild(h("label",{},["Capture de la preuve de paiement",file]));
  var btn=h("button",{type:"submit"},"ENVOYER MA PREUVE");f.appendChild(err);f.appendChild(btn);
  f.addEventListener("submit",async function(e){e.preventDefault();err.textContent="";var fl=file.files[0];if(!fl){err.textContent="Ajoute la capture de paiement.";return;}if(fl.size>5*1024*1024){err.textContent="Image trop lourde (5 Mo maximum).";return;}btn.disabled=true;
    try{var ext=(fl.name.split(".").pop()||"jpg").replace(/[^a-z0-9]/gi,"").slice(0,5)||"jpg",path=p.id+"/"+Date.now()+"."+ext;
      var up=await KV.db.storage.from("proofs").upload(path,fl,{contentType:fl.type});if(up.error)throw up.error;
      await rpc("submit_reseller_request",{p_name:F.name.value.trim(),p_phone:F.phone.value.trim(),p_email:F.email.value.trim(),p_pay_phone:F.pay.value.trim(),p_amount:+F.amount.value,p_proof_path:path});
      toast("Preuve envoyée ✓");await activationView();}catch(x){err.textContent=mapErr(x);}btn.disabled=false;});return f;}
function activatedView(){var b=shell("Félicitations");b.appendChild(h("div",{class:"c"},[h("h3",{},"FÉLICITATIONS ! 🎉"),h("p",{},"Votre compte REVENDEUR KANIS VPN ACADEMY est maintenant activé."),h("p",{},"Bienvenue dans notre réseau de revendeurs ! Vous pouvez maintenant commencer à vendre nos formations."),h("button",{onclick:function(){route();}},"ACCÉDER À MON ESPACE REVENDEUR")]));}
async function activationView(stage){var p=KV.profile,b=shell(p.reseller_status==="suspended"?"Compte suspendu":"Activation du compte revendeur");
  b.appendChild(h("p",{class:"tag"},(p.full_name||p.email)+" · Revendeur · INACTIF"));
  if(p.reseller_status==="suspended"){b.appendChild(h("div",{class:"c"},h("p",{},"Votre compte revendeur est suspendu. Contactez l’administration pour le réactiver.")));b.appendChild(waBlock());b.appendChild(logoutBtn());return;}
  try{var rq=await q(KV.db.from("reseller_requests").select("*").eq("user_id",p.id).order("created_at",{ascending:false}).limit(1)),last=rq[0];
    if(last&&last.status==="pending"){b.appendChild(h("div",{class:"c"},[h("h3",{},"Demande en attente de vérification"),h("p",{},"Votre preuve de paiement a été envoyée. L’administrateur la vérifie manuellement, puis vous enverra votre code d’activation sur WhatsApp."),h("button",{class:"alt",onclick:function(){route();}},"Actualiser")]));}
    else if(stage==="pay"){b.appendChild(h("div",{class:"c"},[h("h3",{},"Paiement des frais d’activation"),h("p",{},"Montant : "+FMT(3000)),h("p",{},"Opérateur : Orange Money Burkina Faso"),h("p",{class:"num"},USSD),
      h("button",{onclick:function(){copyTxt(USSD);}},"COPIER LE CODE DE PAIEMENT"),h("p",{},"Effectuez votre paiement de 3 000 FCFA avec le code ci-dessus, puis envoyez votre preuve de paiement pour recevoir votre code d’activation."),
      h("button",{onclick:function(){activationView("proof");}},"J’AI EFFECTUÉ LE PAIEMENT")]));}
    else if(stage==="proof"){b.appendChild(h("div",{class:"c"},[h("h3",{},"Envoyer ma preuve de paiement"),proofForm(p)]));}
    else{b.appendChild(h("div",{class:"c"},[h("h3",{},"Devenir revendeur"),h("p",{},"Vous souhaitez devenir revendeur KANIS VPN ACADEMY ? Créez votre compte et payez les frais d’activation de 3 000 FCFA pour rejoindre notre réseau."),
      last&&last.status==="refused"?h("p",{class:"err"},"Votre dernière demande a été refusée."+(last.admin_note?" Motif : "+last.admin_note:"")):null,h("button",{onclick:function(){activationView("pay");}},"DEVENIR REVENDEUR")]));}
    b.appendChild(h("div",{class:"c"},[h("h3",{},"Vous avez reçu votre code d’activation ?"),form([{k:"code",l:"Code d’activation"}],"VALIDER MON CODE",async function(v){await rpc("redeem_reseller_code",{p_code:v.code});await loadProfile();activatedView();})]));
  }catch(e){b.appendChild(h("div",{class:"c"},[h("p",{class:"err"},mapErr(e)),h("button",{onclick:function(){activationView();}},"Réessayer")]));}
  b.appendChild(waBlock());b.appendChild(logoutBtn());}

/* ---------- Briques communes ---------- */
function profileCard(){var p=KV.profile;return h("div",{class:"c"},[h("h3",{},"Mon profil"),form([{k:"full_name",l:"Nom",v:p.full_name||""},{k:"phone",l:"Téléphone",t:"tel",v:p.phone||""}],"Enregistrer",async function(v){
  await q(KV.db.from("profiles").update({full_name:v.full_name,phone:v.phone}).eq("id",p.id));toast("Profil mis à jour");})]);}
function payForm(onCreate,extra){var om=(window.CONFIG&&CONFIG.orangeMoney)||"",wv=(window.CONFIG&&CONFIG.wave)||"";
  return form((extra||[]).concat([{k:"provider",l:"Moyen de paiement",opts:[["orange_money","Orange Money"],["wave","Wave"]]},{k:"promo",l:"Code promo (optionnel)"}]),"Valider la commande",async function(v){
    var id=await onCreate(v);alert("Commande enregistrée (réf. "+String(id).slice(0,8)+").\nStatut : EN ATTENTE DE VÉRIFICATION.\nEnvoie le paiement à Orange Money "+om+" / Wave "+wv+" en indiquant cette référence. L’accès n’est débloqué qu’après confirmation réelle du paiement.");dash();});}
function courseOpts(list){return list.map(function(c){return [c.id,c.title+" — "+FMT(c.eff!=null?c.eff:c.price)];});}
function codeReveal(code){prompt("Code d’accès (affiché UNE seule fois — copie-le maintenant) :",code);}

/* ---------- Acheteur ---------- */
function tabsBar(names,cur,set){return h("div",{class:"tabs"},names.map(function(n){return h("button",{class:n===cur?"":"alt",onclick:function(){set(n);dash();}},n);}));}
function lab(s){return STATUS[s]||s;}
var BT=["Formations","Vidéos","Achats","Paiements","Codes","Alertes","Profil"],btab="Formations";
async function buyerView(b){b.appendChild(tabsBar(BT,btab,function(n){btab=n;}));var d=KV.db,me=KV.profile.id;
  if(btab==="Formations"||btab==="Vidéos"){var cs=await priced(await q(d.from("courses").select("*").eq("active",true).order("created_at")));
    if(btab==="Vidéos"){for(var ci=0;ci<cs.length;ci++){var cc=cs[ci],vl=[];try{vl=await rpc("list_course_videos",{p_slug:cc.slug});}catch(e){}b.appendChild(h("h3",{},cc.title));vidList(cc,vl).forEach(function(n){b.appendChild(n);});}}
    else{b.appendChild(rows(cs,function(c){return h("div",{class:"c"},[h("b",{},c.title),h("p",{},c.description||""),priceEl(c),h("button",{class:"alt",onclick:function(){btab="Vidéos";dash();}},"🎬 Vidéos"),KV.has(c.slug)?h("button",{onclick:function(){open(false);window.KANIS.openCourse(c.slug);}},"▶ Regarder"):h("span",{class:"tag"},"Verrouillée")]);}));
      if(cs.length)b.appendChild(h("div",{class:"c"},[h("h3",{},"Acheter une formation"),payForm(function(v){return rpc("create_order",{p_course:v.course,p_promo:v.promo||null,p_provider:v.provider});},[{k:"course",l:"Formation",opts:courseOpts(cs)}])]));}}
  if(btab==="Achats"){var os=await q(d.from("orders").select("*,courses(title)").eq("buyer_id",me).eq("kind","course").order("created_at",{ascending:false}));
    b.appendChild(rows(os,function(o){return row((o.courses?o.courses.title:"Formation")+" · "+FMT(o.amount)+" · "+new Date(o.created_at).toLocaleDateString("fr-FR"),lab(o.status));}));}
  if(btab==="Paiements"){var ps=await q(d.from("payments").select("*,orders(kind,courses(title))").order("created_at",{ascending:false}).limit(100));
    b.appendChild(rows(ps,function(p){var o=p.orders||{};return row((o.kind==="activation"?"Activation":(o.courses?o.courses.title:"Formation"))+" · "+FMT(p.amount)+" · "+(PROV[p.provider]||p.provider)+(p.reference?" · réf. "+p.reference:""),lab(p.status));}));}
  if(btab==="Codes")b.appendChild(h("div",{class:"c"},[h("h3",{},"J’ai un code d’accès"),form([{k:"code",l:"Code"}],"Débloquer",async function(v){var s=await KV.redeem(v.code);if(s){codeOk();}})]));
  if(btab==="Alertes")b.appendChild(await notifCard());
  if(btab==="Profil")b.appendChild(profileCard());}

/* ---------- Revendeur actif ---------- */
var RT=["Accueil","Vendre","Ventes","Clients","Codes","Historique","Paiement","Profil"],rtab="Accueil";
async function resellerView(b){b.appendChild(tabsBar(RT,rtab,function(n){rtab=n;}));var d=KV.db,p=KV.profile;
  var cs=await priced(await q(d.from("courses").select("*").eq("active",true))),os=await q(d.from("orders").select("*,courses(title),payments(provider,status,reference),access_codes(hint,status)").eq("reseller_id",p.id).order("created_at",{ascending:false})),
      cm=await q(d.from("commissions").select("*").eq("reseller_id",p.id).order("created_at",{ascending:false})),ok=os.filter(function(o){return o.status==="confirmed";}),
      tot=cm.reduce(function(s,c){return s+c.reseller_amount;},0),ca=ok.reduce(function(s,o){return s+o.amount;},0),wait=os.filter(function(o){return o.status==="pending";}).length;
  function gen(o){return h("button",{onclick:async function(){try{codeReveal(await rpc("generate_code",{p_order:o.id}));dash();}catch(e){toast(e.message);}}},"Générer le code");}
  if(rtab==="Paiement"||rtab==="Vendre"){var pm=await q(d.from("reseller_payment_methods").select("*").eq("reseller_id",p.id).order("created_at"));
    if(rtab==="Vendre"){if(pm.length)b.appendChild(h("div",{class:"c"},[h("h3",{},"Tes moyens de paiement (visibles par tes clients)")].concat(pm.map(function(m){return h("p",{},m.operator+" · "+m.number+" · "+m.holder_name+(m.instructions?" — "+m.instructions:""));}))));}
    else{b.appendChild(h("div",{class:"c"},[h("h3",{},"Ajouter un moyen de paiement"),form([{k:"op",l:"Opérateur",opts:[["Orange Money","Orange Money"],["Moov Money","Moov Money"],["Wave","Wave"],["Autre","Autre (personnalisé)"]]},{k:"custom",l:"Nom si « Autre »"},{k:"num",l:"Numéro de paiement",t:"tel"},{k:"holder",l:"Nom du titulaire"},{k:"ins",l:"Instructions de paiement"}],"Ajouter",async function(v){
        if(!v.num||!v.holder)throw new Error("Numéro et titulaire requis.");await q(d.from("reseller_payment_methods").insert({reseller_id:p.id,operator:v.op==="Autre"&&v.custom?v.custom:v.op,number:v.num,holder_name:v.holder,instructions:v.ins||null}));dash();})]));
      b.appendChild(rows(pm,function(m){var k=h("div",{class:"c"},[h("b",{},m.operator+" · "+m.number),h("p",{},"Titulaire : "+m.holder_name),h("p",{class:"tag"},m.instructions||"")]);
        k.appendChild(form([{k:"num",l:"Numéro",t:"tel",v:m.number},{k:"holder",l:"Titulaire",v:m.holder_name},{k:"ins",l:"Instructions",v:m.instructions||""}],"Modifier",async function(v){await q(d.from("reseller_payment_methods").update({number:v.num,holder_name:v.holder,instructions:v.ins||null}).eq("id",m.id));dash();}));
        k.appendChild(h("button",{class:"alt",onclick:async function(){if(!confirm("Supprimer ce moyen de paiement ?"))return;await q(d.from("reseller_payment_methods").delete().eq("id",m.id));dash();}},"Supprimer"));return k;}));}}
  if(rtab==="Accueil"){b.appendChild(h("p",{class:"tag"},"Statut du compte : ACTIF ✓"));
    b.appendChild(h("div",{class:"k"},[["Solde",FMT(p.balance)],["Commissions",FMT(tot)],["Ventes confirmées",ok.length],["En attente",wait],["Chiffre vendu",FMT(ca)],["Commandes",os.length]].map(function(x){return h("div",{class:"c"},[x[0],h("b",{},x[1])]);})));}
  if(rtab==="Vendre")b.appendChild(h("div",{class:"c"},[h("h3",{},"Nouvelle vente (client)"),h("p",{class:"tag"},"Ta commission : 90 % du prix, calculée par le serveur après confirmation du paiement."),
    cs.length?payForm(function(v){return rpc("create_order",{p_course:v.course,p_promo:v.promo||null,p_provider:v.provider,p_client_name:v.cname,p_client_phone:v.cphone||null});},
      [{k:"course",l:"Formation",opts:courseOpts(cs)},{k:"cname",l:"Nom du client"},{k:"cphone",l:"Téléphone du client",t:"tel"}]):h("p",{},"Aucune formation disponible.")]));
  if(rtab==="Ventes")b.appendChild(rows(os,function(o){var r=h("div",{class:"row"},[h("span",{},(o.client_name||"")+" · "+(o.courses?o.courses.title:"")+" · "+FMT(o.amount)),h("span",{},lab(o.status))]);
    if(o.status==="confirmed"&&!(o.access_codes&&o.access_codes.length))r.appendChild(gen(o));return r;}));
  if(rtab==="Clients"){var seen={};b.appendChild(rows(os.filter(function(o){if(!o.client_name)return false;var k=o.client_name+"|"+(o.client_phone||"");if(seen[k]){seen[k].n++;seen[k].t+=o.status==="confirmed"?o.amount:0;return false;}seen[k]={n:1,t:o.status==="confirmed"?o.amount:0};o._s=seen[k];return true;}),
    function(o){return row(o.client_name+(o.client_phone?" · "+o.client_phone:""),o._s.n+" achat(s) · "+FMT(o._s.t));}));}
  if(rtab==="Codes"){var todo=os.filter(function(o){return o.status==="confirmed"&&!(o.access_codes&&o.access_codes.length);}),done=os.filter(function(o){return o.access_codes&&o.access_codes.length;});
    b.appendChild(h("h3",{},"Codes à générer"));b.appendChild(rows(todo,function(o){var r=row((o.client_name||"")+" · "+(o.courses?o.courses.title:""),"");r.lastChild.appendChild(gen(o));return r;}));
    b.appendChild(h("h3",{},"Codes générés (jamais stockés en clair)"));b.appendChild(rows(done,function(o){return row((o.client_name||"")+" · …"+o.access_codes[0].hint,o.access_codes[0].status==="used"?"Utilisé":o.access_codes[0].status==="revoked"?"Révoqué":"Non utilisé");}));}
  if(rtab==="Historique"){b.appendChild(h("h3",{},"Commissions"));b.appendChild(rows(cm,function(c){return row(new Date(c.created_at).toLocaleDateString("fr-FR")+" · vente",FMT(c.reseller_amount));}));
    b.appendChild(h("h3",{},"Paiements des ventes"));b.appendChild(rows(os,function(o){var pay=(o.payments&&o.payments[0])||{};return row((o.client_name||"")+" · "+FMT(o.amount)+" · "+(PROV[pay.provider]||""),lab(o.status));}));}
  if(rtab==="Profil"){b.appendChild(profileCard());b.appendChild(await notifCard());}}

/* ---------- Administrateur ---------- */
var ATABS=["Acheteurs","Revendeurs","Demandes revendeurs","Formations","Vidéos","Prix","Promotions","Promotion des prix","Paiements","Commissions","Codes","Notifications","Réglages"],atab="Demandes revendeurs";
async function adminView(b){var t=h("div",{class:"tabs"},ATABS.map(function(n){return h("button",{class:n===atab?"":"alt",onclick:function(){atab=n;dash();}},n);}));b.appendChild(t);var d=KV.db;
  if(atab==="Stats"){var s=await rpc("admin_stats");b.appendChild(h("div",{class:"k"},[["Acheteurs",s.buyers],["Revendeurs",s.resellers],["Ventes",s.sales],["Chiffre d’affaires",FMT(s.revenue)],["Commissions",FMT(s.commissions)],["Revenus académie",FMT(s.academy)]].map(function(x){return h("div",{class:"c"},[x[0],h("b",{},x[1])]);})));}
  if(atab==="Acheteurs"||atab==="Revendeurs"){var us=await q(d.from("profiles").select("*").in("role",atab==="Acheteurs"?["buyer","admin"]:["reseller"]).order("created_at",{ascending:false}).limit(200));b.appendChild(rows(us,function(u){var r=h("div",{class:"row"},[h("span",{},(u.full_name||u.email)+" · "+u.role+(u.role==="reseller"?" ("+u.reseller_status+")":"")),h("span",{})]);
    if(u.id!==KV.profile.id)r.lastChild.appendChild(h("button",{class:"alt",onclick:async function(){var n=prompt("Nouveau rôle pour "+(u.full_name||u.email)+" : buyer, reseller ou admin",u.role);if(!n)return;try{await rpc("admin_set_role",{p_user:u.id,p_role:n.trim()});dash();}catch(e){toast(e.message);}}},"Rôle"));
    if(u.role==="reseller")r.lastChild.appendChild(h("button",{onclick:async function(){try{await rpc("admin_set_reseller",{p_user:u.id,p_status:u.reseller_status==="active"?"suspended":"active"});dash();}catch(e){toast(e.message);}}},u.reseller_status==="active"?"Suspendre":"Activer"));return r;}));}
  if(atab==="Formations"){var cs=await q(d.from("courses").select("*").order("created_at"));b.appendChild(rows(cs,function(c){return h("div",{class:"c"},[form([{k:"title",l:"Titre",v:c.title},{k:"description",l:"Description",v:c.description||""},{k:"price",l:"Prix (FCFA)",t:"number",v:c.price},{k:"cover_url",l:"Image (URL)",v:c.cover_url||""},{k:"active",l:"Statut",opts:[["true","Actif"],["false","Inactif"]],v:String(c.active)}],"Enregistrer",async function(v){
      await q(d.from("courses").update({title:v.title,description:v.description,price:+v.price,cover_url:v.cover_url,active:v.active==="true"}).eq("id",c.id));toast("Enregistré");}),
      h("button",{class:"alt",onclick:async function(){if(confirm("Supprimer cette formation ?")){try{await q(d.from("courses").delete().eq("id",c.id));dash();}catch(e){toast(e.message);}}}},"Supprimer")]);}));
    b.appendChild(h("div",{class:"c"},[h("h3",{},"Ajouter une formation"),form([{k:"slug",l:"Identifiant (ex: nouveau-tunnel)"},{k:"title",l:"Titre"},{k:"price",l:"Prix",t:"number",v:"2500"}],"Ajouter",async function(v){await q(d.from("courses").insert({slug:v.slug,title:v.title,price:+v.price}));dash();})]));}
  if(atab==="Vidéos"){var cs2=await q(d.from("courses").select("id,title")),vs=await q(d.from("videos").select("*,courses(title)").order("position")),chs=await q(d.from("chapters").select("*,courses(title)"));
    b.appendChild(h("div",{class:"c"},[h("h3",{},"Ajouter un chapitre"),form([{k:"course",l:"Formation",opts:cs2.map(function(c){return [c.id,c.title];})},{k:"title",l:"Titre du chapitre"}],"Ajouter",async function(v){await q(d.from("chapters").insert({course_id:v.course,title:v.title}));dash();})]));
    b.appendChild(h("div",{class:"c"},[h("h3",{},"Ajouter une vidéo"),vidForm(cs2,chs)]));
    b.appendChild(rows(vs,function(v){var k=h("div",{class:"c"},[h("b",{},(v.courses?v.courses.title+" · ":"")+v.title+(v.is_active?"":" (désactivée)")),h("p",{},v.description||"")]);
      k.appendChild(form([{k:"title",l:"Titre",v:v.title},{k:"description",l:"Description détaillée",v:v.description||""},{k:"pos",l:"Ordre d’affichage",t:"number",v:String(v.position||0)}],"Enregistrer",async function(x){await q(d.from("videos").update({title:x.title,description:x.description,position:+x.pos}).eq("id",v.id));toast("Enregistré");}));
      k.appendChild(h("button",{class:"alt",onclick:async function(){await q(d.from("videos").update({is_active:!v.is_active}).eq("id",v.id));dash();}},v.is_active?"Désactiver":"Activer"));
      k.appendChild(h("button",{class:"alt",onclick:async function(){if(!confirm("Supprimer cette vidéo ?"))return;await q(d.from("videos").delete().eq("id",v.id));dash();}},"Supprimer"));return k;}));}
  if(atab==="Demandes revendeurs"){
    if(KV.lastCode){var lc=KV.lastCode;b.appendChild(h("div",{class:"c"},[h("h3",{},"Code d’activation généré"),h("p",{class:"num"},lc.code),h("p",{class:"tag"},"Affiché une seule fois. Copiez-le et envoyez-le à "+lc.name+" sur WhatsApp."),h("button",{onclick:function(){copyTxt(lc.code);}},"COPIER LE CODE"),
      h("a",{href:waUrl(lc.phone,"Bonjour "+lc.name+", voici votre code d’activation revendeur KANIS VPN ACADEMY : "+lc.code),target:"_blank",rel:"noopener",style:WAST},"ENVOYER SUR WHATSAPP"),h("button",{class:"alt",onclick:function(){KV.lastCode=null;dash();}},"Fermer")]));}
    var rqs=await q(d.from("reseller_requests").select("*").order("created_at",{ascending:false}).limit(100));
    var sg=await Promise.all(rqs.map(function(r){return KV.db.storage.from("proofs").createSignedUrl(r.proof_path,300);}));
    b.appendChild(rows(rqs,function(r,i){var u=sg[i]&&sg[i].data&&sg[i].data.signedUrl,c=h("div",{class:"c"},[h("b",{},r.full_name+" · "+({pending:"EN ATTENTE",approved:"ACCEPTÉE",refused:"REFUSÉE"}[r.status]||r.status)),
        h("p",{},"Tél : "+r.phone+" · E-mail : "+r.email),h("p",{},"Payé depuis : "+r.pay_phone+" · "+FMT(r.amount)+" · "+new Date(r.created_at).toLocaleDateString("fr-FR")),u?h("a",{href:u,target:"_blank",rel:"noopener"},"Voir la preuve de paiement"):h("p",{class:"tag"},"Preuve indisponible")]);
      if(r.status==="pending"){c.appendChild(h("button",{onclick:async function(){if(!confirm("Avez-vous vérifié manuellement ce paiement sur votre compte Orange Money ?"))return;try{var code=await rpc("admin_review_request",{p_id:r.id,p_decision:"approved"});KV.lastCode={code:code,name:r.full_name,phone:r.phone};dash();}catch(e){toast(mapErr(e));}}},"ACCEPTER ET GÉNÉRER LE CODE"));
        c.appendChild(h("button",{class:"alt",onclick:async function(){var n=prompt("Motif du refus (optionnel)","");if(n===null)return;try{await rpc("admin_review_request",{p_id:r.id,p_decision:"refused",p_note:n||null});dash();}catch(e){toast(mapErr(e));}}},"REFUSER"));}
      return c;}));}
  if(atab==="Promotion des prix"){var cs4=await q(d.from("courses").select("id,title,price")),pp=await q(d.from("price_promos").select("*,courses(title,price)").order("created_at",{ascending:false}));
    b.appendChild(h("div",{class:"c"},[h("h3",{},"Nouvelle promotion de prix"),form([{k:"course",l:"Formation",opts:cs4.map(function(c){return [c.id,c.title+" — "+FMT(c.price)];})},{k:"price",l:"Prix promotionnel (FCFA)",t:"number"},{k:"starts",l:"Début",t:"datetime-local"},{k:"ends",l:"Fin",t:"datetime-local"}],"Créer",async function(v){
      if(!v.price||!v.ends)throw new Error("Prix et date de fin requis.");await q(d.from("price_promos").insert({course_id:v.course,promo_price:+v.price,starts_at:v.starts?new Date(v.starts).toISOString():null,ends_at:new Date(v.ends).toISOString()}));dash();})]));
    b.appendChild(rows(pp,function(x){var r=row((x.courses?x.courses.title:"")+" · "+FMT(x.promo_price)+" (au lieu de "+FMT(x.courses?x.courses.price:0)+") · fin "+new Date(x.ends_at).toLocaleDateString("fr-FR"),"");
      r.lastChild.appendChild(h("button",{class:"alt",onclick:async function(){await q(d.from("price_promos").update({active:!x.active}).eq("id",x.id));dash();}},x.active?"Désactiver":"Activer"));
      r.lastChild.appendChild(h("button",{class:"alt",onclick:async function(){await q(d.from("price_promos").delete().eq("id",x.id));dash();}},"Supprimer"));return r;}));}
  if(atab==="Promotions"){var cs3=await q(d.from("courses").select("id,title")),pr=await q(d.from("promotions").select("*").order("code"));
    b.appendChild(h("div",{class:"c"},[h("h3",{},"Nouvelle promotion"),form([{k:"code",l:"Code promotionnel"},{k:"kind",l:"Type",opts:[["percent","Pourcentage"],["fixed","Réduction fixe (FCFA)"]]},{k:"value",l:"Valeur",t:"number"},{k:"starts",l:"Début",t:"datetime-local"},{k:"ends",l:"Expiration",t:"datetime-local"},{k:"max",l:"Utilisations max (vide = illimité)",t:"number"},
      {k:"scope",l:"Concerne",opts:[["all","Toutes les formations"]].concat(cs3.map(function(c){return [c.id,c.title];})).concat([["activation","Activation revendeur"]])}],"Créer",async function(v){
      await q(d.from("promotions").insert({code:v.code.toUpperCase(),kind:v.kind,value:+v.value,starts_at:v.starts?new Date(v.starts).toISOString():null,ends_at:v.ends?new Date(v.ends).toISOString():null,max_uses:v.max?+v.max:null,
        course_ids:v.scope==="all"||v.scope==="activation"?[]:[v.scope],applies_to_activation:v.scope==="activation"}));dash();})]));
    b.appendChild(rows(pr,function(p){var r=row(p.code+" · "+(p.kind==="percent"?p.value+" %":FMT(p.value))+(p.applies_to_activation?" · activation revendeur":"")+" · "+p.uses+"/"+(p.max_uses||"∞"),"");
      r.lastChild.appendChild(h("button",{class:"alt",onclick:async function(){await q(d.from("promotions").update({active:!p.active}).eq("id",p.id));dash();}},p.active?"Désactiver":"Activer"));return r;}));}
  if(atab==="Prix"){var cp=await q(d.from("courses").select("id,title,price").order("created_at")),sp=await q(d.from("settings").select("*").in("key",["reseller_activation_price","reseller_share_percent"]));
    b.appendChild(h("h3",{},"Prix des formations"));cp.forEach(function(c){b.appendChild(h("div",{class:"c"},form([{k:"price",l:c.title+" (FCFA)",t:"number",v:c.price}],"Enregistrer",async function(v){if(!(+v.price>=0))throw new Error("Prix invalide");await q(d.from("courses").update({price:+v.price}).eq("id",c.id));toast("Prix enregistré");})));});
    b.appendChild(h("h3",{},"Activation revendeur et commissions"));sp.forEach(function(s){b.appendChild(h("div",{class:"c"},form([{k:"v",l:s.key==="reseller_activation_price"?"Prix d’activation revendeur (FCFA)":"Part du revendeur (%)",t:"number",v:s.value}],"Enregistrer",async function(v){if(!(+v.v>=0))throw new Error("Valeur invalide");await q(d.from("settings").update({value:String(+v.v)}).eq("key",s.key));toast("Enregistré");})));});}
  if(atab==="Commissions"){var cmx=await q(d.from("commissions").select("*,profiles(full_name,email),orders(amount,courses(title))").order("created_at",{ascending:false}).limit(200));
    b.appendChild(h("p",{class:"tag"},"Total revendeurs : "+FMT(cmx.reduce(function(s,c){return s+c.reseller_amount;},0))+" · Académie : "+FMT(cmx.reduce(function(s,c){return s+c.academy_amount;},0))));
    b.appendChild(rows(cmx,function(c){var o=c.orders||{},p=c.profiles||{};return row((p.full_name||p.email||"")+" · "+(o.courses?o.courses.title:"")+" · vente "+FMT(o.amount),FMT(c.reseller_amount)+" / "+FMT(c.academy_amount));}));}
  if(atab==="Paiements"){var ps=await q(d.from("payments").select("*,orders(amount,kind,client_name,courses(title),profiles!orders_buyer_id_fkey(full_name,email))").order("created_at",{ascending:false}).limit(200));
    b.appendChild(rows(ps,function(p){var o=p.orders||{},r=h("div",{class:"row"},[h("span",{},String(p.id).slice(0,8)+" · "+(o.kind==="activation"?"Activation":(o.courses?o.courses.title:""))+" · "+FMT(p.amount)+" · "+p.provider+" · "+p.status),h("span",{})]);
      var act=function(l,fn,alt){r.lastChild.appendChild(h("button",{class:alt?"alt":"",onclick:async function(){try{await fn();dash();}catch(e){toast(e.message);}}},l));};
      if(p.status==="pending"){act("Confirmer",function(){var ref=prompt("Référence de la transaction (SMS Orange Money / Wave) :");if(!ref)throw new Error("Référence requise");return rpc("confirm_payment",{p_payment:p.id,p_reference:ref});});act("Refuser",function(){return rpc("refuse_payment",{p_payment:p.id});},1);}
      if(p.status==="confirmed")act("Rembourser",function(){if(!confirm("Rembourser et annuler commission/accès ?"))throw new Error("Annulé");return rpc("refuse_payment",{p_payment:p.id,p_refund:true});},1);return r;}));}
  if(atab==="Codes"){var os=await q(d.from("orders").select("id,client_name,amount,courses(title)").eq("status","confirmed").eq("kind","course")),cd=await q(d.from("access_codes").select("*,courses(title)").order("created_at",{ascending:false}).limit(200)),used={};cd.forEach(function(c){used[c.order_id]=1;});
    b.appendChild(h("h3",{},"Commandes confirmées sans code"));b.appendChild(rows(os.filter(function(o){return !used[o.id];}),function(o){var r=row((o.client_name||"")+" · "+(o.courses?o.courses.title:"")+" · "+FMT(o.amount),"");r.lastChild.appendChild(h("button",{onclick:async function(){try{codeReveal(await rpc("generate_code",{p_order:o.id}));dash();}catch(e){toast(e.message);}}},"Générer"));return r;}));
    b.appendChild(h("h3",{},"Codes générés (valeur jamais stockée en clair)"));b.appendChild(rows(cd,function(c){return row((c.courses?c.courses.title:"")+" · …"+c.hint,c.status);}));}
  if(atab==="Notifications")b.appendChild(h("div",{class:"c"},[form([{k:"title",l:"Titre"},{k:"body",l:"Message"}],"Envoyer à tous",async function(v){await q(d.from("notifications").insert({user_id:null,title:v.title,body:v.body}));toast("Notification publiée");})]));
  if(atab==="Réglages"){var st=await q(d.from("settings").select("*"));b.appendChild(rows(st,function(s){return h("div",{class:"c"},[form([{k:"v",l:s.key,v:s.value}],"Enregistrer",async function(v){await q(d.from("settings").update({value:v.v}).eq("key",s.key));toast("Enregistré");})]);}));}}

/* ---------- Tableau de bord (acheteur / revendeur actif / administrateur) ---------- */
async function dash(){if(!KV.session){welcome();return;}stopPoll();root.textContent="";root.className="kv";var b=h("div",{class:"in"});root.appendChild(b);open(true);
  try{var r=await loadProfile();KV.profile=r;
    if(r.role==="reseller"&&r.reseller_status!=="active"){KV.locked=true;await activationView();return;}
    KV.locked=false;await KV.refresh();
    b.appendChild(head({buyer:"Espace acheteur",reseller:"Espace revendeur",admin:"Administration"}[r.role]));
    b.appendChild(h("p",{class:"tag"},(r.full_name||r.email)+" · "+{buyer:"Acheteur",reseller:"Revendeur actif",admin:"Administrateur"}[r.role]));
    b.appendChild(h("button",{class:"alt",onclick:function(){open(false);}},"▶ Accéder aux formations et outils"));
    if(r.role==="admin")await adminView(b);else if(r.role==="reseller")await resellerView(b);else await buyerView(b);
    if(r.role==="admin")b.appendChild(await notifCard());
    b.appendChild(logoutBtn());
  }catch(e){b.appendChild(h("p",{class:"err"},mapErr(e)));b.appendChild(h("button",{onclick:function(){route();}},"Réessayer"));b.appendChild(logoutBtn());}}
KV.openAccount=function(){if(KV.session&&KV.profile&&!KV.locked){open(true);dash();}else route();};
/* Retour matériel Android : navigation dans les onglets du compte, puis retour
   à l’accueil public. Un revendeur non activé reste sur l’écran d’activation. */
KV.handleBack=function(){
  if(root.hidden)return false;
  if(!KV.session){welcome();return true;}
  if(KV.profile&&KV.profile.role==="reseller"&&KV.profile.reseller_status!=="active"){
    toast("L’activation du compte est obligatoire avant de continuer.");return true;
  }
  if(KV.profile&&KV.profile.role==="buyer"&&btab!==BT[0]){btab=BT[0];dash();return true;}
  if(KV.profile&&KV.profile.role==="reseller"&&rtab!==RT[0]){rtab=RT[0];dash();return true;}
  if(KV.profile&&KV.profile.role==="admin"&&atab!==ATABS[0]){atab=ATABS[0];dash();return true;}
  open(false);
  if(window.KANIS&&typeof window.KANIS.show==="function")window.KANIS.show("home");
  return true;
};

/* ---------- Démarrage ---------- */
function addMenu(){var d=document.getElementById("drawer");if(!d)return;d.appendChild(h("button",{type:"button",style:"margin:12px;padding:12px;border-radius:12px;border:0;font-weight:700;background:var(--accent);color:var(--accent-ink)",onclick:function(){var m=document.getElementById("scrim");if(m)m.click();KV.openAccount();}},"👤 Mon compte"));}
function hideSplash(){var s=document.getElementById("kvSplash");if(s){s.classList.add("out");setTimeout(function(){if(s.parentNode)s.parentNode.removeChild(s);},450);}}
function boot(){var t0=Date.now(),done=function(){setTimeout(hideSplash,Math.max(0,1500-(Date.now()-t0)));};addMenu();KV.locked=true;
  if(!C.url||!C.anonKey||!window.supabase){var b=shell("Configuration manquante");b.appendChild(h("div",{class:"c"},[h("p",{class:"err"},"Le serveur Supabase n’est pas configuré (www/js/config.js) ou la bibliothèque supabase.js est absente (npm run vendor)."),h("button",{onclick:function(){location.reload();}},"Réessayer")]));KV.openAccount=function(){};done();return;}
  KV.on=true;KV.db=window.supabase.createClient(C.url,C.anonKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:!NATIVE}});
  wireDeepLinks();
  KV.db.auth.onAuthStateChange(function(ev,s){KV.session=s;
    if(ev==="SIGNED_OUT"&&!KV.leaving)setTimeout(function(){KV.profile=null;KV.access=[];KV.locked=true;welcome();},0);
    if(ev==="PASSWORD_RECOVERY")setTimeout(recoveryView,0);});
  KV.db.auth.getSession().then(function(r){KV.session=r.data.session;return route();}).catch(function(e){var b=shell("Démarrage impossible");b.appendChild(h("div",{class:"c"},[h("p",{class:"err"},mapErr(e)),h("button",{onclick:function(){location.reload();}},"Réessayer")]));}).then(done);}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",boot);else boot();
})();
